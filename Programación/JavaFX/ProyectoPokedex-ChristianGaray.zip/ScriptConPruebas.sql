select tipo_pokedexidnombreusuarionombre from pokedex.region order by id;
insert into pokedex.usuario(nombreUsuario, nombre, apellido, contrasena, rol, region_id,tipo_pokedex_id) values('Christian1156','Christian','Garay','user01','Campeon', 5, 6); 
select * from pokedex.usuario;

ALTER TABLE pokedex.usuario AUTO_INCREMENT = 0;

delete from pokedex.usuario where id = 3;
select nombreUsuario, contrasena from pokedex.usuario where nombreUsuario = 'Christian1156';
select usur.id "id", usur.nombreUsuario "nombre usuario", usur.nombre "nombre", usur.apellido "apellido", usur.rol "rol", reg.nombre "region", tp.nombre "tipo_pokedex"
from pokedex.usuario usur
join pokedex.region reg
on usur.region_id = reg.id
join pokedex.tipo_pokedex tp
on usur.tipo_pokedex_id = tp.id;

SELECT 
    p.id,
    p.nombre,
    p.altura,
    p.peso,
    t1.nombre AS tipo1,
    t2.nombre AS tipo2,
    p.descripcion,
    p.sprite_modelo,
    p.baseHp,
    p.baseAtq,
    p.baseDef,
    p.baseAtqEsp,
    p.baseDefEsp,
    p.basevel,
    p.ratioCaptura,
    r.id AS region_origen
FROM pokedex.pokemon p
LEFT JOIN pokedex.pokemon_tipo pt1 ON p.id = pt1.pokemon_id AND pt1.tipo_id = 1
LEFT JOIN pokedex.tipo t1 ON pt1.tipo_id = t1.id
LEFT JOIN pokedex.pokemon_tipo pt2 ON p.id = pt2.pokemon_id AND pt2.tipo_id = 2
LEFT JOIN pokedex.tipo t2 ON pt2.tipo_id = t2.id
LEFT JOIN pokedex.region r ON p.region_origen_id = r.id
order by p.id;

SELECT 
    m.id,
    m.nombre,
    t.nombre "tipo",
    c.nombre "categoria",
    m.potencia,
    m.precision_mov,
    m.pp,
    m.descripcion
FROM movimiento m
JOIN pokedex.pokemon_movimientos pm ON m.id = pm.movimiento_id
JOIN pokedex.tipo t ON m.tipo_id = t.id
JOIN pokedex.categoria_movimiento c ON m.categoria_id = c.id
WHERE pm.pokemon_id = 1
order by id;

select * from pokedex.tipo order by id;